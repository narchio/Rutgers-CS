class Synapse: 
	def __init__(self, preneuron, postneuron, weight): 
		self.preneuron = preneuron
		self.postneuron = postneuron
		self.weight = weight

