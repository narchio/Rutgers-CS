'''
*** Authors: Nicolas Carchio and Oliver Gilan *** 
	
	Root-Level DNS server (RS)
	- maintains a DNS_table of three fields: 
		- Hostname
		- IP address
		- Flag (A or NS)
	1. reads in DNS records from a file 
		- dictionary to maintain the table 
	2. client sends queried hostname as a string to TS
	3. The TS program looks up the hostname in its DNS_table (dictionary) 
		3a. if there is a match, we sent the entry as a string
		3b. if there is no match, we send an error message: "Error:HOST NOT FOUND"
'''

import sys
import socket
import select

port = int(sys.argv[1])
ts1Host = sys.argv[2]
ts1Port = int(sys.argv[3])
ts2Host = sys.argv[4]
ts2Port = int(sys.argv[5])

ts1 = None
ts2 = None

try:
    ts1=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ts1.connect((ts1Host, ts1Port))
except socket.error as err:
    print('{} \n'.format("socket open error ",err))

try:
    ts2=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ts2.connect((ts2Host, ts2Port))
except socket.error as err:
    print('{} \n'.format("socket open error ",err))

#  establish socket and start listening on the port
try:
    ls_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ls_socket.bind(('', port))
    ls_socket.listen(1)
except socket.error as err:
    print('{} \n'.format("socket open error ",err))
print "LS server has been initialized at host: {}, and is listening for connections on port: {}".format(socket.gethostname(), port)

client,addr=ls_socket.accept()
while True:
    try: 
        msg = client.recv(256)
        ts1.send(msg)
        ts2.send(msg)
        re, wr, er = select.select([ts1, ts2], [],  [], 5.0)
        
        if len(re) == 0: 
            client.send('{} - Error: HOST NOT FOUND\n'.format(msg))
        elif(re[0]!= None):
            msg1 = re[0].recv(256)
            client.send(msg1)
        else:
            msg2 = re[1].recv(256)
            client.send(msg2)
    except socket.error as er:
        print ("Client connection has been terminated")
        break

ls_socket.close()
