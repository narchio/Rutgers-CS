'''
*** Authors: Nicolas Carchio and Oliver Gilan *** 
	
	Client-Level Script
	1. reads in hostnames from a file 
		- Loops line by line
	2. Sends hostname as a string to RS
        - Checks response flag. If
            - A: write to file
            - NS: send hostname to TS
        - Prints error if no response
	3. Write response to file
'''
import sys
import socket
import select

lsHost = sys.argv[1]
lsPort = int(sys.argv[2])
fileName = "PROJ2-HNS.txt"

buffer = 256

try:
    cs=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    cs.connect((lsHost, lsPort))
    # print("[C]: Client socket created")
except socket.error as err:
    print('{} \n'.format("socket open error ",err))

with open(fileName) as infile:
    with open("RESOLVED.txt", "w+") as outfile:
        for line in infile:
            sanitized = line.lower().strip("\r\n")
            cs.send(sanitized)
            response = cs.recv(256)
            outfile.write(response)

cs.close()