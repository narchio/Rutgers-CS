0. Oliver Gilan (olg7) && Nicolas Carchio (nfc28)

1. Used the instructions listed in the assignment description. 
	a. We first set up the Mininet on our local machines. 
	b. We then used the topology Python file (AS352.py) to invoke Python API to create a network topology with 4 endpoints (h1,h2,h3,h4) and 1 router (r1). 
	c. We attached IP's to the hosts, and then ensured that the router pointed to each of the hosts in the network. 
	d. Finally, we used the trace route commands to ensure that all hosts were connected and functioning correctly with the router.  
	e. Overall, we followed all the instructions and our network works as intended!
2. No, it seems to all work.
3. None, it was fairly straight forward after downloading the necessary materials.
4. We now have a better understanding in how a router is set up with multiple hosts. 

